/**
  ******************************************************************************
  * @file     : FAN.c
  * @author   : AW    Adrian.Wojcik@put.poznan.pl
  * @version  : 1.3.0
  * @date     : Nov 27, 2022
  * @brief    : Electric FAN components driver
  *
  ******************************************************************************
  */

/* Private includes ----------------------------------------------------------*/
#include "fan.h"

/* Private typedef -----------------------------------------------------------*/

/* Private define ------------------------------------------------------------*/

/* Private macro -------------------------------------------------------------*/

/* Private variables ---------------------------------------------------------*/

/* Public variables ----------------------------------------------------------*/

/* Private function prototypes -----------------------------------------------*/

/* Public function prototypes ------------------------------------------------*/

/* Private functions ---------------------------------------------------------*/

/* Public functions ----------------------------------------------------------*/
/**
  * @brief Turns FAN on
  * @param[in] hfan   : FAN DIO handler
  * @retval None
  */
void FAN_DIO_On(const FAN_DIO_Handle_TypeDef* hfan)
{
  FAN_DIO_Write(hfan, FAN_ON);
}

/**
  * @brief Turns FAN off
  * @param[in] hfan   : FAN DIO handler
  * @retval None
  */
void FAN_DIO_Off(const FAN_DIO_Handle_TypeDef* hfan)
{
  FAN_DIO_Write(hfan, FAN_OFF);
}

/**
  * @brief Toggles FAN state
  * @param[in] hfan   : FAN DIO handler
  * @retval None
  */
void FAN_DIO_Toggle(const FAN_DIO_Handle_TypeDef* hfan)
{
  DIO_Toggle(&(hfan->Output));
}

/**
  * @brief Writes given FAN state
  * @param[in] hfan   : FAN DIO handler
  * @param[in] state  : FAN state (FAN_OFF or FAN_ON)
  * @retval None
  */
void FAN_DIO_Write(const FAN_DIO_Handle_TypeDef* hfan, FAN_DIO_State_TypeDef state)
{
  DIO_Write(&(hfan->Output), (hfan->ActiveState == FAN_ON_HIGH) ? state : !state);
}

/**
  * @brief Reads FAN state
  * @param[in] hfan   : FAN GPIO handler
  * @retval FAN state (FAN_OFF or FAN_ON)
  */
FAN_DIO_State_TypeDef FAN_DIO_Read(const FAN_DIO_Handle_TypeDef* hfan)
{
  _Bool state = DIO_Read(&(hfan->Output));
  return (hfan->ActiveState == FAN_ON_HIGH) ? state : !state;
}

/**
  * @brief Initialize PWM FAN control
  * @param[in] hfan   : FAN PWM handler
  * @retval None
  */
void FAN_PWM_Init(FAN_PWM_Handle_TypeDef* hfan)
{
  hfan->Output.Duty = (hfan->ActiveState == FAN_ON_HIGH) ? (hfan->Output.Duty) : (100.0f - hfan->Output.Duty);
  PWM_Init(&(hfan->Output));
}

/**
  * @brief Write PWM duty cycle
  * @param[in/out] hfan   : FAN PWM handler
  * @param[in]     duty   : PWM duty cycle in percents (0. - 100.)
  * @retval None
  */
void FAN_PWM_WriteDuty(FAN_PWM_Handle_TypeDef* hfan, float duty)
{
  hfan->Output.Duty = (hfan->ActiveState == FAN_ON_HIGH) ? (duty) : (100.0f - duty);
  PWM_WriteDuty(&(hfan->Output), hfan->Output.Duty);
}

/**
  * @brief Set PWM duty cycle
  * @param[in] hfan   : FAN PWM handler
  * @retval PWM duty cycle in percents (0. - 100.)
  */
float FAN_PWM_ReadDuty(const FAN_PWM_Handle_TypeDef* hfan)
{
  return (hfan->ActiveState == FAN_ON_HIGH) ? (hfan->Output.Duty) : (100.0f - hfan->Output.Duty);
}
